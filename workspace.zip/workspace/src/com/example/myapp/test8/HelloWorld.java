package com.example.myapp.test8;

/**
 * Created by sjyin on 14-10-13.
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
