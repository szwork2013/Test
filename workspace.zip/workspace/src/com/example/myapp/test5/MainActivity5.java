package com.example.myapp.test5;

import android.app.Activity;
import android.os.Bundle;
import com.example.myapp.R;

/**
 * Created by sjyin on 14-10-8.
 */
public class MainActivity5 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
    }
}
