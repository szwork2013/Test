package com.example.myapp.test;

import junit.framework.TestCase;

/**
 * Created by sjyin on 14-9-1.
 */
public class MemoryTest extends TestCase{

    public void testMemory(){
        System.out.print("test run");
    }
}
