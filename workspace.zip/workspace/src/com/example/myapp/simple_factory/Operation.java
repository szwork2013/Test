package com.example.myapp.simple_factory;

/**
 * Created by sjyin on 14-10-15.
 */
public abstract class Operation {
    protected double num1;
    protected double num2;
    public abstract double getResult();
}
